-- ============================================================
--  Northstar Logistics — SQL Server Demo Database
--  SQLBits Demo, KGorman, 04/2026
--  Tool: ora2pg (adapted for SQL Server / FreeTDS)
-- ============================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'NorthstarLogistics')
BEGIN
    CREATE DATABASE NorthstarLogistics;
END
GO

USE NorthstarLogistics;
GO

-- ── Drop tables in FK-safe order if re-running ──────────────
IF OBJECT_ID('dbo.audit_log',    'U') IS NOT NULL DROP TABLE dbo.audit_log;
IF OBJECT_ID('dbo.order_items',  'U') IS NOT NULL DROP TABLE dbo.order_items;
IF OBJECT_ID('dbo.shipments',    'U') IS NOT NULL DROP TABLE dbo.shipments;
IF OBJECT_ID('dbo.orders',       'U') IS NOT NULL DROP TABLE dbo.orders;
IF OBJECT_ID('dbo.inventory',    'U') IS NOT NULL DROP TABLE dbo.inventory;
IF OBJECT_ID('dbo.products',     'U') IS NOT NULL DROP TABLE dbo.products;
IF OBJECT_ID('dbo.routes',       'U') IS NOT NULL DROP TABLE dbo.routes;
IF OBJECT_ID('dbo.warehouses',   'U') IS NOT NULL DROP TABLE dbo.warehouses;
IF OBJECT_ID('dbo.carriers',     'U') IS NOT NULL DROP TABLE dbo.carriers;
IF OBJECT_ID('dbo.customers',    'U') IS NOT NULL DROP TABLE dbo.customers;
IF OBJECT_ID('dbo.employees',    'U') IS NOT NULL DROP TABLE dbo.employees;
IF OBJECT_ID('dbo.departments',  'U') IS NOT NULL DROP TABLE dbo.departments;
GO

-- ============================================================
--  TABLES
-- ============================================================

CREATE TABLE dbo.departments (
    department_id   INT           IDENTITY(1,1) PRIMARY KEY,
    dept_name       NVARCHAR(100) NOT NULL,
    cost_center     CHAR(6)       NOT NULL,
    created_at      DATETIME2     NOT NULL DEFAULT GETDATE()
);

CREATE TABLE dbo.employees (
    employee_id     INT           IDENTITY(1,1) PRIMARY KEY,
    department_id   INT           NOT NULL,
    first_name      NVARCHAR(80)  NOT NULL,
    last_name       NVARCHAR(80)  NOT NULL,
    email           NVARCHAR(150) NOT NULL UNIQUE,
    hire_date       DATE          NOT NULL,
    salary          DECIMAL(10,2) NOT NULL,
    is_active       BIT           NOT NULL DEFAULT 1,
    CONSTRAINT fk_emp_dept FOREIGN KEY (department_id)
        REFERENCES dbo.departments(department_id)
);

CREATE TABLE dbo.customers (
    customer_id     INT           IDENTITY(1,1) PRIMARY KEY,
    company_name    NVARCHAR(200) NOT NULL,
    contact_name    NVARCHAR(150) NOT NULL,
    email           NVARCHAR(150) NOT NULL UNIQUE,
    phone           NVARCHAR(30),
    address_line1   NVARCHAR(255),
    city            NVARCHAR(100),
    state_province  NVARCHAR(100),
    postal_code     NVARCHAR(20),
    country         NVARCHAR(100) NOT NULL DEFAULT 'US',
    credit_limit    DECIMAL(12,2) NOT NULL DEFAULT 50000.00,
    created_at      DATETIME2     NOT NULL DEFAULT GETDATE(),
    is_active       BIT           NOT NULL DEFAULT 1
);

CREATE TABLE dbo.carriers (
    carrier_id      INT           IDENTITY(1,1) PRIMARY KEY,
    carrier_name    NVARCHAR(150) NOT NULL,
    scac_code       CHAR(4)       NOT NULL UNIQUE,   -- Standard Carrier Alpha Code
    service_type    NVARCHAR(50)  NOT NULL,           -- LTL, FTL, PARCEL, AIR
    base_rate_per_mile DECIMAL(8,4) NOT NULL,
    is_active       BIT           NOT NULL DEFAULT 1
);

CREATE TABLE dbo.warehouses (
    warehouse_id    INT           IDENTITY(1,1) PRIMARY KEY,
    warehouse_code  CHAR(6)       NOT NULL UNIQUE,
    warehouse_name  NVARCHAR(150) NOT NULL,
    address         NVARCHAR(255) NOT NULL,
    city            NVARCHAR(100) NOT NULL,
    state_province  NVARCHAR(50)  NOT NULL,
    capacity_sqft   INT           NOT NULL,
    manager_emp_id  INT,
    is_active       BIT           NOT NULL DEFAULT 1
);

CREATE TABLE dbo.routes (
    route_id        INT           IDENTITY(1,1) PRIMARY KEY,
    origin_wh_id    INT           NOT NULL,
    dest_wh_id      INT           NOT NULL,
    carrier_id      INT           NOT NULL,
    distance_miles  DECIMAL(8,2)  NOT NULL,
    transit_days    TINYINT       NOT NULL,
    is_active       BIT           NOT NULL DEFAULT 1,
    CONSTRAINT fk_route_origin  FOREIGN KEY (origin_wh_id)  REFERENCES dbo.warehouses(warehouse_id),
    CONSTRAINT fk_route_dest    FOREIGN KEY (dest_wh_id)    REFERENCES dbo.warehouses(warehouse_id),
    CONSTRAINT fk_route_carrier FOREIGN KEY (carrier_id)    REFERENCES dbo.carriers(carrier_id)
);

CREATE TABLE dbo.products (
    product_id      INT           IDENTITY(1,1) PRIMARY KEY,
    sku             NVARCHAR(50)  NOT NULL UNIQUE,
    product_name    NVARCHAR(200) NOT NULL,
    category        NVARCHAR(100) NOT NULL,
    unit_weight_lbs DECIMAL(8,3)  NOT NULL,
    unit_price      DECIMAL(10,2) NOT NULL,
    hazmat_flag     BIT           NOT NULL DEFAULT 0,
    is_active       BIT           NOT NULL DEFAULT 1
);

CREATE TABLE dbo.inventory (
    inventory_id    INT           IDENTITY(1,1) PRIMARY KEY,
    warehouse_id    INT           NOT NULL,
    product_id      INT           NOT NULL,
    qty_on_hand     INT           NOT NULL DEFAULT 0,
    qty_reserved    INT           NOT NULL DEFAULT 0,
    reorder_point   INT           NOT NULL DEFAULT 10,
    last_updated    DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_inv_wh   FOREIGN KEY (warehouse_id) REFERENCES dbo.warehouses(warehouse_id),
    CONSTRAINT fk_inv_prod FOREIGN KEY (product_id)   REFERENCES dbo.products(product_id),
    CONSTRAINT uq_inv_wh_prod UNIQUE (warehouse_id, product_id)
);

CREATE TABLE dbo.orders (
    order_id        INT           IDENTITY(1,1) PRIMARY KEY,
    customer_id     INT           NOT NULL,
    employee_id     INT           NOT NULL,   -- sales rep
    order_date      DATETIME2     NOT NULL DEFAULT GETDATE(),
    required_date   DATE          NOT NULL,
    status          NVARCHAR(30)  NOT NULL DEFAULT 'PENDING',  -- PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED
    priority        TINYINT       NOT NULL DEFAULT 2,          -- 1=HIGH, 2=NORMAL, 3=LOW
    total_amount    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    notes           NVARCHAR(MAX),
    CONSTRAINT fk_ord_cust FOREIGN KEY (customer_id) REFERENCES dbo.customers(customer_id),
    CONSTRAINT fk_ord_emp  FOREIGN KEY (employee_id) REFERENCES dbo.employees(employee_id),
    CONSTRAINT chk_order_status CHECK (status IN ('PENDING','CONFIRMED','SHIPPED','DELIVERED','CANCELLED'))
);

CREATE TABLE dbo.order_items (
    item_id         INT           IDENTITY(1,1) PRIMARY KEY,
    order_id        INT           NOT NULL,
    product_id      INT           NOT NULL,
    warehouse_id    INT           NOT NULL,
    quantity        INT           NOT NULL,
    unit_price      DECIMAL(10,2) NOT NULL,
    discount_pct    DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    line_total      AS (quantity * unit_price * (1 - discount_pct/100)),   -- computed column
    CONSTRAINT fk_oi_order FOREIGN KEY (order_id)     REFERENCES dbo.orders(order_id),
    CONSTRAINT fk_oi_prod  FOREIGN KEY (product_id)   REFERENCES dbo.products(product_id),
    CONSTRAINT fk_oi_wh    FOREIGN KEY (warehouse_id) REFERENCES dbo.warehouses(warehouse_id)
);

CREATE TABLE dbo.shipments (
    shipment_id         INT           IDENTITY(1,1) PRIMARY KEY,
    order_id            INT           NOT NULL,
    route_id            INT           NOT NULL,
    tracking_number     NVARCHAR(100) NOT NULL UNIQUE,
    ship_date           DATETIME2,
    estimated_delivery  DATE,
    actual_delivery     DATETIME2,
    status              NVARCHAR(30)  NOT NULL DEFAULT 'PENDING',
    weight_lbs          DECIMAL(10,3),
    freight_cost        DECIMAL(10,2),
    CONSTRAINT fk_ship_order FOREIGN KEY (order_id)  REFERENCES dbo.orders(order_id),
    CONSTRAINT fk_ship_route FOREIGN KEY (route_id)  REFERENCES dbo.routes(route_id),
    CONSTRAINT chk_ship_status CHECK (status IN ('PENDING','IN_TRANSIT','DELIVERED','EXCEPTION','RETURNED'))
);

CREATE TABLE dbo.audit_log (
    log_id          BIGINT        IDENTITY(1,1) PRIMARY KEY,
    table_name      NVARCHAR(100) NOT NULL,
    operation       CHAR(1)       NOT NULL,   -- I=Insert, U=Update, D=Delete
    record_id       INT           NOT NULL,
    changed_by      NVARCHAR(150),
    changed_at      DATETIME2     NOT NULL DEFAULT GETDATE(),
    old_values      NVARCHAR(MAX),
    new_values      NVARCHAR(MAX)
);
GO

-- ============================================================
--  INDEXES
-- ============================================================

-- Customers
CREATE INDEX idx_customers_email    ON dbo.customers(email);
CREATE INDEX idx_customers_company  ON dbo.customers(company_name);
CREATE INDEX idx_customers_active   ON dbo.customers(is_active) WHERE is_active = 1;

-- Orders
CREATE INDEX idx_orders_customer    ON dbo.orders(customer_id);
CREATE INDEX idx_orders_status_date ON dbo.orders(status, order_date DESC);
CREATE INDEX idx_orders_employee    ON dbo.orders(employee_id);

-- Order Items
CREATE INDEX idx_oi_order           ON dbo.order_items(order_id);
CREATE INDEX idx_oi_product         ON dbo.order_items(product_id);

-- Shipments
CREATE INDEX idx_ship_order         ON dbo.shipments(order_id);
CREATE INDEX idx_ship_tracking      ON dbo.shipments(tracking_number);
CREATE INDEX idx_ship_status        ON dbo.shipments(status);

-- Inventory
CREATE INDEX idx_inv_reorder        ON dbo.inventory(warehouse_id, product_id)
    WHERE qty_on_hand <= reorder_point;

-- Audit log
CREATE INDEX idx_audit_table_date   ON dbo.audit_log(table_name, changed_at DESC);
GO

-- ============================================================
--  STORED PROCEDURES
-- ============================================================

-- SP 1: Place a new order (business logic, transactions, error handling)
CREATE OR ALTER PROCEDURE dbo.usp_PlaceOrder
    @customer_id    INT,
    @employee_id    INT,
    @required_date  DATE,
    @priority       TINYINT = 2,
    @notes          NVARCHAR(MAX) = NULL,
    @new_order_id   INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Validate customer exists and is active
        IF NOT EXISTS (
            SELECT 1 FROM dbo.customers
            WHERE customer_id = @customer_id AND is_active = 1
        )
        BEGIN
            RAISERROR('Customer %d not found or inactive.', 16, 1, @customer_id);
        END

        -- Validate required date is in the future
        IF @required_date <= CAST(GETDATE() AS DATE)
        BEGIN
            RAISERROR('Required date must be in the future.', 16, 1);
        END

        INSERT INTO dbo.orders (
            customer_id, employee_id, required_date, priority, notes, status
        )
        VALUES (
            @customer_id, @employee_id, @required_date, @priority, @notes, 'PENDING'
        );

        SET @new_order_id = SCOPE_IDENTITY();

        -- Audit
        INSERT INTO dbo.audit_log (table_name, operation, record_id, changed_by, new_values)
        VALUES ('orders', 'I', @new_order_id, SYSTEM_USER,
                '{"status":"PENDING","customer_id":' + CAST(@customer_id AS VARCHAR) + '}');

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        DECLARE @msg NVARCHAR(2048) = ERROR_MESSAGE();
        RAISERROR(@msg, 16, 1);
    END CATCH
END;
GO

-- SP 2: Get customer order summary (cursor + conditional logic)
CREATE OR ALTER PROCEDURE dbo.usp_CustomerOrderSummary
    @customer_id    INT,
    @include_cancelled BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @order_id       INT;
    DECLARE @order_date     DATETIME2;
    DECLARE @status         NVARCHAR(30);
    DECLARE @total          DECIMAL(12,2);
    DECLARE @item_count     INT;
    DECLARE @priority_label NVARCHAR(20);

    -- Temp table to hold results
    CREATE TABLE #summary (
        order_id        INT,
        order_date      DATETIME2,
        status          NVARCHAR(30),
        priority_label  NVARCHAR(20),
        item_count      INT,
        order_total     DECIMAL(12,2),
        has_shipment    CHAR(3)
    );

    DECLARE order_cursor CURSOR FOR
        SELECT o.order_id, o.order_date, o.status, o.total_amount
        FROM   dbo.orders o
        WHERE  o.customer_id = @customer_id
          AND  (@include_cancelled = 1 OR o.status <> 'CANCELLED')
        ORDER  BY o.order_date DESC;

    OPEN order_cursor;
    FETCH NEXT FROM order_cursor INTO @order_id, @order_date, @status, @total;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Map priority integer to label
        SELECT @priority_label = CASE priority
            WHEN 1 THEN 'HIGH'
            WHEN 2 THEN 'NORMAL'
            ELSE        'LOW'
        END
        FROM dbo.orders WHERE order_id = @order_id;

        -- Count line items
        SELECT @item_count = COUNT(*)
        FROM   dbo.order_items
        WHERE  order_id = @order_id;

        INSERT INTO #summary
        SELECT
            @order_id,
            @order_date,
            @status,
            @priority_label,
            @item_count,
            @total,
            CASE WHEN EXISTS (
                SELECT 1 FROM dbo.shipments WHERE order_id = @order_id
            ) THEN 'YES' ELSE 'NO' END;

        FETCH NEXT FROM order_cursor INTO @order_id, @order_date, @status, @total;
    END

    CLOSE order_cursor;
    DEALLOCATE order_cursor;

    SELECT * FROM #summary ORDER BY order_date DESC;
    DROP TABLE #summary;
END;
GO

-- SP 3: Reorder inventory (checks reorder points, creates replenishment records)
CREATE OR ALTER PROCEDURE dbo.usp_CheckAndReorderInventory
    @warehouse_id   INT = NULL,   -- NULL = all warehouses
    @dry_run        BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @reorder_table TABLE (
        warehouse_id    INT,
        warehouse_code  CHAR(6),
        product_id      INT,
        sku             NVARCHAR(50),
        qty_on_hand     INT,
        reorder_point   INT,
        suggested_qty   INT,
        estimated_cost  DECIMAL(10,2)
    );

    INSERT INTO @reorder_table
    SELECT
        i.warehouse_id,
        w.warehouse_code,
        i.product_id,
        p.sku,
        i.qty_on_hand,
        i.reorder_point,
        -- Suggest ordering 3x reorder point to avoid frequent reorders
        i.reorder_point * 3            AS suggested_qty,
        (i.reorder_point * 3) * p.unit_price AS estimated_cost
    FROM       dbo.inventory   i
    INNER JOIN dbo.warehouses  w ON w.warehouse_id  = i.warehouse_id
    INNER JOIN dbo.products    p ON p.product_id    = i.product_id
    WHERE i.qty_on_hand <= i.reorder_point
      AND p.is_active = 1
      AND w.is_active = 1
      AND (@warehouse_id IS NULL OR i.warehouse_id = @warehouse_id);

    -- Always return the report
    SELECT
        warehouse_code,
        sku,
        qty_on_hand     AS current_stock,
        reorder_point,
        suggested_qty,
        estimated_cost,
        CASE WHEN @dry_run = 1 THEN 'DRY RUN — no action taken'
             ELSE 'REORDER QUEUED' END AS action_taken
    FROM @reorder_table
    ORDER BY estimated_cost DESC;

    -- In real mode, log each reorder to audit
    IF @dry_run = 0
    BEGIN
        DECLARE @wh_id INT, @prod_id INT, @qty INT;
        DECLARE reorder_cur CURSOR FOR
            SELECT warehouse_id, product_id, suggested_qty FROM @reorder_table;

        OPEN reorder_cur;
        FETCH NEXT FROM reorder_cur INTO @wh_id, @prod_id, @qty;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO dbo.audit_log (table_name, operation, record_id, changed_by, new_values)
            VALUES ('inventory', 'U', @prod_id, 'SYSTEM_REORDER',
                    '{"action":"reorder_queued","warehouse_id":' + CAST(@wh_id AS VARCHAR) +
                    ',"qty":' + CAST(@qty AS VARCHAR) + '}');
            FETCH NEXT FROM reorder_cur INTO @wh_id, @prod_id, @qty;
        END
        CLOSE reorder_cur;
        DEALLOCATE reorder_cur;
    END
END;
GO

-- ============================================================
--  SEED DATA
-- ============================================================

-- Departments
INSERT INTO dbo.departments (dept_name, cost_center) VALUES
('Operations',       'OPS001'),
('Sales',            'SAL002'),
('Logistics',        'LOG003'),
('Finance',          'FIN004'),
('Human Resources',  'HR0005');

-- Employees (20)
INSERT INTO dbo.employees (department_id, first_name, last_name, email, hire_date, salary) VALUES
(1, 'Marcus',   'Thornton',   'mthornton@northstar.com',   '2018-03-12', 95000),
(1, 'Priya',    'Nair',       'pnair@northstar.com',       '2019-07-22', 88000),
(2, 'James',    'Okafor',     'jokafor@northstar.com',     '2017-01-15', 72000),
(2, 'Sandra',   'Kowalski',   'skowalski@northstar.com',   '2020-04-03', 68000),
(2, 'Derek',    'Fontaine',   'dfontaine@northstar.com',   '2021-09-17', 65000),
(3, 'Yuki',     'Tanaka',     'ytanaka@northstar.com',     '2016-06-28', 105000),
(3, 'Carlos',   'Mendez',     'cmendez@northstar.com',     '2019-11-05', 92000),
(3, 'Amara',    'Diallo',     'adiallo@northstar.com',     '2022-02-14', 78000),
(4, 'Helen',    'Briggs',     'hbriggs@northstar.com',     '2015-08-31', 115000),
(4, 'Tom',      'Vasquez',    'tvasquez@northstar.com',    '2018-12-20', 98000),
(5, 'Linda',    'Achebe',     'lachebe@northstar.com',     '2017-05-09', 85000),
(1, 'Raj',      'Patel',      'rpatel@northstar.com',      '2020-08-18', 82000),
(2, 'Olivia',   'Chen',       'ochen@northstar.com',       '2021-03-25', 71000),
(3, 'Nathan',   'Osei',       'nosei@northstar.com',       '2019-09-12', 89000),
(2, 'Fatima',   'Al-Hassan',  'falhassan@northstar.com',   '2022-07-01', 67000),
(1, 'Ben',      'Wu',         'bwu@northstar.com',         '2023-01-10', 75000),
(3, 'Carla',    'Rivera',     'crivera@northstar.com',     '2018-10-22', 94000),
(4, 'Ian',      'MacLeod',    'imacleod@northstar.com',    '2016-03-07', 108000),
(5, 'Zoe',      'Adeyemi',    'zadeyemi@northstar.com',    '2021-11-30', 80000),
(2, 'Patrick',  'Donnelly',   'pdonnelly@northstar.com',   '2020-06-15', 69000);

-- Customers (25)
INSERT INTO dbo.customers (company_name, contact_name, email, phone, address_line1, city, state_province, postal_code, country, credit_limit) VALUES
('Apex Manufacturing Inc.',      'Robert Sloane',     'rsloane@apexmfg.com',        '312-555-0101', '400 Industrial Blvd',      'Chicago',      'IL', '60601', 'US', 250000),
('Pacific Rim Exports',          'Mei Ling',          'mling@pacrimex.com',          '206-555-0202', '1200 Harbor Way',          'Seattle',      'WA', '98101', 'US', 175000),
('Great Lakes Distributors',     'Todd Kaminski',     'tkaminski@gld.com',           '313-555-0303', '88 Lake Shore Dr',         'Detroit',      'MI', '48201', 'US', 120000),
('Sunbelt Supply Co.',           'Angela Torres',     'atorres@sunbeltsupply.com',   '602-555-0404', '3300 Desert View Rd',      'Phoenix',      'AZ', '85001', 'US', 90000),
('Coastal Freight LLC',          'Bruce Harmon',      'bharmon@coastalfreight.com',  '305-555-0505', '77 Port Access Rd',        'Miami',        'FL', '33101', 'US', 200000),
('Midwest Wholesale Group',      'Karen Schultz',     'kschultz@mwwholesale.com',   '612-555-0606', '501 Commerce Pkwy',        'Minneapolis',  'MN', '55401', 'US', 160000),
('TexStar Industries',           'Dale Hutchins',     'dhutchins@texstar.com',       '713-555-0707', '9200 Energy Corridor Dr',  'Houston',      'TX', '77001', 'US', 300000),
('Mountain Peak Logistics',      'Sara Whitfield',    'swhitfield@mtpklog.com',      '720-555-0808', '2100 Rocky Ridge Blvd',    'Denver',       'CO', '80201', 'US', 85000),
('Atlantic Traders Corp.',       'Michael Reeves',    'mreeves@atlantictraders.com', '617-555-0909', '150 Seaport Ave',          'Boston',       'MA', '02101', 'US', 220000),
('Valley Fresh Foods',           'Christine Nakamura','cnakamura@valleyfresh.com',   '559-555-1010', '4400 Harvest Lane',        'Fresno',       'CA', '93701', 'US', 75000),
('Delta Cross Transport',        'Jerome Williams',   'jwilliams@deltacross.com',    '901-555-1111', '600 River Bend Rd',        'Memphis',      'TN', '38101', 'US', 140000),
('NovaTech Components',          'Emily Zhao',        'ezhao@novatech.com',          '408-555-1212', '8800 Silicon Ave',         'San Jose',     'CA', '95101', 'US', 350000),
('Keystone Building Materials',  'Frank DeLuca',      'fdeluca@keystonebm.com',      '215-555-1313', '300 Broad St',             'Philadelphia', 'PA', '19101', 'US', 180000),
('Great Northern Supply',        'Ingrid Sorensen',   'isorensen@gnorthsupply.com',  '701-555-1414', '110 Prairie Ave',          'Fargo',        'ND', '58101', 'US', 60000),
('Lakeview Medical Supplies',    'David Park',        'dpark@lakeviewmed.com',        '847-555-1515', '2250 Healthcare Blvd',     'Evanston',     'IL', '60201', 'US', 200000),
('Rio Grande Trading Co.',       'Maria Espinoza',    'mespinoza@rgtrading.com',     '505-555-1616', '700 Camino Real',          'Albuquerque',  'NM', '87101', 'US', 95000),
('Cascade Electronics',          'Kevin Larsen',      'klarsen@cascadeelec.com',     '503-555-1717', '1500 Tech Park Dr',        'Portland',     'OR', '97201', 'US', 280000),
('Capital City Distributors',    'Nancy Foster',      'nfoster@capcd.com',           '804-555-1818', '900 Main Street',          'Richmond',     'VA', '23219', 'US', 130000),
('Bayou Industrial Parts',       'Tyrone Jackson',    'tjackson@bayouindustrial.com','504-555-1919', '450 Canal St',             'New Orleans',  'LA', '70112', 'US', 110000),
('Northern Lights Imports',      'Astrid Bjornsen',   'abjornsen@nli.com',           '907-555-2020', '200 Aurora Blvd',          'Anchorage',    'AK', '99501', 'US', 70000),
('Gulf Coast Chemicals',         'Steve Petrocelli',  'spetrocelli@gcchem.com',      '251-555-2121', '3100 Refinery Row',        'Mobile',       'AL', '36601', 'US', 250000),
('Prairie Wind Energy',          'Donna Hartley',     'dhartley@prairiewind.com',    '785-555-2222', '600 Turbine Way',          'Wichita',      'KS', '67201', 'US', 115000),
('Ironwood Timber Group',        'Leo Vandenberg',    'lvandenberg@ironwoodtg.com',  '406-555-2323', '50 Sawmill Rd',            'Billings',     'MT', '59101', 'US', 80000),
('Quantum Data Systems',         'Priya Anand',       'panand@quantumds.com',        '512-555-2424', '1700 Innovation Campus',   'Austin',       'TX', '78701', 'US', 320000),
('Harbor Bridge Freight',        'Connor O''Brien',   'cobrien@harborbfr.com',       '401-555-2525', '85 Wharf St',              'Providence',   'RI', '02901', 'US', 145000);

-- Carriers (6)
INSERT INTO dbo.carriers (carrier_name, scac_code, service_type, base_rate_per_mile) VALUES
('FastTrack Freight',    'FTRK', 'FTL',    2.85),
('Reliable LTL Inc.',   'RLTL', 'LTL',    3.40),
('SwiftParcel USA',     'SWFT', 'PARCEL', 0.62),
('AirBridge Cargo',     'AIRB', 'AIR',    8.50),
('CrossCountry Haul',   'CXHY', 'FTL',    2.65),
('Metro Express',       'MXPR', 'PARCEL', 0.55);

-- Warehouses (5)
INSERT INTO dbo.warehouses (warehouse_code, warehouse_name, address, city, state_province, capacity_sqft, manager_emp_id) VALUES
('WH-CHI', 'Chicago Central',      '1000 Logistics Way',     'Chicago',     'IL', 250000, 1),
('WH-LAX', 'Los Angeles West',     '5500 Harbor Freeway',    'Los Angeles', 'CA', 320000, 6),
('WH-ATL', 'Atlanta Southeast',    '800 Peachtree Ind Blvd', 'Atlanta',     'GA', 180000, 7),
('WH-DFW', 'Dallas-Fort Worth',    '2200 Alliance Gateway',  'Fort Worth',  'TX', 275000, 14),
('WH-NYC', 'New York/NJ Gateway',  '100 Newark Port Rd',     'Newark',      'NJ', 210000, 17);

-- Routes (10)
INSERT INTO dbo.routes (origin_wh_id, dest_wh_id, carrier_id, distance_miles, transit_days) VALUES
(1, 2, 1, 2017, 4),
(1, 3, 2, 718,  2),
(1, 4, 5, 920,  2),
(1, 5, 2, 790,  1),
(2, 3, 1, 2181, 4),
(2, 4, 5, 1399, 3),
(3, 5, 2, 865,  2),
(4, 5, 1, 1604, 3),
(2, 5, 4, 2802, 1),
(3, 4, 2, 662,  2);

-- Products (20)
INSERT INTO dbo.products (sku, product_name, category, unit_weight_lbs, unit_price, hazmat_flag) VALUES
('SKU-10001', 'Industrial Hydraulic Pump',      'Machinery',     145.00,  2850.00, 0),
('SKU-10002', 'Electric Motor 5HP',             'Electrical',     62.50,   875.00, 0),
('SKU-10003', 'Steel Pipe Fitting 2in',         'Hardware',        1.20,    18.50, 0),
('SKU-10004', 'Safety Valve Assembly',          'Safety',          8.75,   245.00, 0),
('SKU-10005', 'Industrial Lubricant 55gal',     'Chemicals',     440.00,   320.00, 1),
('SKU-10006', 'Conveyor Belt 50ft',             'Machinery',     280.00,  1450.00, 0),
('SKU-10007', 'LED Work Light Array',           'Electrical',      9.50,   185.00, 0),
('SKU-10008', 'Heavy-Duty Pallet Jack',         'Material Handling',220.00, 695.00, 0),
('SKU-10009', 'Forklift Tines 48in',            'Material Handling', 85.00, 425.00, 0),
('SKU-10010', 'Compressed Gas Cylinder N2',     'Chemicals',      52.00,   195.00, 1),
('SKU-10011', 'Warehouse Racking Unit',         'Storage',        180.00,  1200.00, 0),
('SKU-10012', 'Digital Torque Wrench',          'Tools',            3.20,   310.00, 0),
('SKU-10013', 'Pneumatic Drill',                'Tools',            8.80,   490.00, 0),
('SKU-10014', 'Safety Harness Kit',             'Safety',           4.50,   155.00, 0),
('SKU-10015', 'Thermal Imaging Camera',         'Electronics',      2.10,  2200.00, 0),
('SKU-10016', 'Industrial Ethernet Switch',     'Electronics',      4.80,   850.00, 0),
('SKU-10017', 'Fiber Optic Cable 1000ft',       'Electronics',     65.00,   480.00, 0),
('SKU-10018', 'Heavy Duty Shelving Unit',       'Storage',         95.00,   380.00, 0),
('SKU-10019', 'Bar Code Scanner Handheld',      'Electronics',      0.85,   220.00, 0),
('SKU-10020', 'Stretch Wrap Machine',           'Packaging',      155.00,  1750.00, 0);

-- Inventory (5 warehouses × 20 products = 100 rows)
INSERT INTO dbo.inventory (warehouse_id, product_id, qty_on_hand, qty_reserved, reorder_point)
SELECT w.warehouse_id, p.product_id,
    ABS(CHECKSUM(NEWID())) % 200 + 5   AS qty_on_hand,
    ABS(CHECKSUM(NEWID())) % 20        AS qty_reserved,
    15                                  AS reorder_point
FROM dbo.warehouses w CROSS JOIN dbo.products p;

-- Orders (50 orders across customers)
DECLARE @i INT = 1;
WHILE @i <= 50
BEGIN
    DECLARE @cust_id INT = (@i % 25) + 1;
    DECLARE @emp_id  INT = (@i % 5) + 3;   -- sales reps in dept 2
    DECLARE @status  NVARCHAR(30) = CASE @i % 5
        WHEN 0 THEN 'DELIVERED'
        WHEN 1 THEN 'SHIPPED'
        WHEN 2 THEN 'CONFIRMED'
        WHEN 3 THEN 'PENDING'
        ELSE        'CANCELLED'
    END;
    DECLARE @req_date DATE = DATEADD(day, @i + 5, CAST(GETDATE() AS DATE));

    INSERT INTO dbo.orders (customer_id, employee_id, required_date, status, priority, total_amount)
    VALUES (@cust_id, @emp_id, @req_date, @status, (@i % 3) + 1,
            CAST(ABS(CHECKSUM(NEWID())) % 50000 + 500 AS DECIMAL(12,2)));

    SET @i = @i + 1;
END;

-- Order items (2-4 per order, ~150 rows total)
DECLARE @ord_id INT = 1;
WHILE @ord_id <= 50
BEGIN
    DECLARE @items INT = (@ord_id % 3) + 2;
    DECLARE @j INT = 1;
    WHILE @j <= @items
    BEGIN
        DECLARE @prod_id INT = ((@ord_id + @j) % 20) + 1;
        DECLARE @wh_id   INT = (@ord_id % 5) + 1;
        DECLARE @qty     INT = (@j * 3) + 1;

        INSERT INTO dbo.order_items (order_id, product_id, warehouse_id, quantity, unit_price, discount_pct)
        SELECT @ord_id, @prod_id, @wh_id, @qty, unit_price,
               CAST((@ord_id % 10) AS DECIMAL(5,2))
        FROM   dbo.products WHERE product_id = @prod_id;

        SET @j = @j + 1;
    END;
    SET @ord_id = @ord_id + 1;
END;

-- Shipments (for SHIPPED and DELIVERED orders)
INSERT INTO dbo.shipments (order_id, route_id, tracking_number, ship_date, estimated_delivery, actual_delivery, status, weight_lbs, freight_cost)
SELECT
    o.order_id,
    (o.order_id % 10) + 1                        AS route_id,
    'NS' + RIGHT('000000' + CAST(o.order_id AS VARCHAR), 6) + 'A' AS tracking_number,
    DATEADD(day, -10, GETDATE())                  AS ship_date,
    DATEADD(day, -6,  CAST(GETDATE() AS DATE))    AS estimated_delivery,
    CASE o.status WHEN 'DELIVERED' THEN DATEADD(day, -5, GETDATE()) ELSE NULL END AS actual_delivery,
    CASE o.status WHEN 'DELIVERED' THEN 'DELIVERED' ELSE 'IN_TRANSIT' END AS status,
    CAST(ABS(CHECKSUM(NEWID())) % 2000 + 100 AS DECIMAL(10,3)) AS weight_lbs,
    CAST(ABS(CHECKSUM(NEWID())) % 3000 + 200 AS DECIMAL(10,2)) AS freight_cost
FROM dbo.orders o
WHERE o.status IN ('SHIPPED','DELIVERED');

-- Audit log entries
INSERT INTO dbo.audit_log (table_name, operation, record_id, changed_by, new_values)
SELECT 'orders', 'I', order_id, 'seed_script',
       '{"status":"' + status + '","customer_id":' + CAST(customer_id AS VARCHAR) + '}'
FROM dbo.orders;

PRINT 'NorthstarLogistics database initialized successfully.';
GO
