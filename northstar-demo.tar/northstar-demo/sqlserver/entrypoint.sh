#!/bin/bash
# ============================================================
#  SQL Server entrypoint — starts SQL Server then auto-seeds
#  SQLBits Demo, Yes this is BASH, Don't shame me... KGorman
# ============================================================

/opt/mssql/bin/sqlservr &
MSSQL_PID=$!

echo "Waiting for SQL Server to accept connections..."
for i in $(seq 1 60); do
    /opt/mssql-tools18/bin/sqlcmd \
        -S localhost -U sa -P "NorthstarDemo#2024" \
        -Q "SELECT 1" -No -C \
        > /dev/null 2>&1 && break
    echo "  attempt $i/60 — not ready yet..."
    sleep 2
done

DB_EXISTS=$(/opt/mssql-tools18/bin/sqlcmd \
    -S localhost -U sa -P "NorthstarDemo#2024" -No -C \
    -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM sys.databases WHERE name='NorthstarLogistics'" \
    2>/dev/null | tr -d ' \r\n' | grep -o '[0-9]*' | head -1)

if [ "$DB_EXISTS" = "1" ]; then
    echo "NorthstarLogistics already exists — skipping seed."
else
    echo "Seeding NorthstarLogistics database..."
    /opt/mssql-tools18/bin/sqlcmd \
        -S localhost -U sa -P "NorthstarDemo#2024" \
        -i /tmp/init.sql -No -C
    echo "Seed complete."
fi

wait $MSSQL_PID
