# Northstar Logistics — SQL Server -> PostgreSQL Migration Demo

Simple migration using only sqlcmd and psql inside Docker containers.
No third party tools. Runs on Windows with Python 3.

---

## Setup (night before)

```powershell
docker compose up -d sqlserver postgres
```

Wait 60 seconds, verify SQL Server seeded:

```powershell
docker exec northstar_sqlserver /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "NorthstarDemo#2024" -d NorthstarLogistics -Q "SELECT name FROM sys.tables ORDER BY name;" -No -C
```

---

## On Stage — 4 commands

### 1. Show SQL Server has data
```powershell
docker exec northstar_sqlserver /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "NorthstarDemo#2024" -d NorthstarLogistics -Q "SELECT name FROM sys.tables ORDER BY name;" -No -C
```

### 2. Show PostgreSQL is empty
```powershell
docker exec northstar_postgres psql -U northstar -d northstar_logistics -c "\dt"
```

### 3. Run the migration
```powershell
python migration\migrate.py
```

### 4. Show PostgreSQL has data and row counts
```powershell
docker exec northstar_postgres psql -U northstar -d northstar_logistics -c "SELECT tablename AS table_name, (xpath('/row/cnt/text()', query_to_xml('SELECT COUNT(*) AS cnt FROM '||tablename,false,true,'')))[1]::text::int AS row_count FROM pg_tables WHERE schemaname='public' ORDER BY tablename;"
```

---

## Credentials

| Service    | Port | User     | Password            | Database            |
|------------|------|----------|---------------------|---------------------|
| SQL Server | 1433 | sa       | NorthstarDemo#2024  | NorthstarLogistics  |
| PostgreSQL | 5434 | northstar| northstar_pg_2024   | northstar_logistics |

---

## Full Reset

```powershell
docker compose down -v
docker compose up -d sqlserver postgres
```
