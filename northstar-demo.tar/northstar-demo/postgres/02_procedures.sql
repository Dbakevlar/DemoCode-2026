-- ============================================================
--  SQLBits Demo, KGorman, 04/2026, PostgreSQL Stored Procedures
--  These are the manually-corrected PL/pgSQL versions after
--  ora2pg conversion. 
-- ============================================================

-- ── SP 1: Place Order ────────────────────────────────────────────
CREATE OR REPLACE FUNCTION usp_place_order(
    p_customer_id   INT,
    p_employee_id   INT,
    p_required_date DATE,
    p_priority      SMALLINT DEFAULT 2,
    p_notes         TEXT     DEFAULT NULL
)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
    v_new_order_id INT;
BEGIN
    -- Validate customer exists and is active
    IF NOT EXISTS (
        SELECT 1 FROM customers
        WHERE customer_id = p_customer_id AND is_active = TRUE
    ) THEN
        RAISE EXCEPTION 'Customer % not found or inactive.', p_customer_id;
    END IF;

    -- Validate required date
    IF p_required_date <= CURRENT_DATE THEN
        RAISE EXCEPTION 'Required date must be in the future.';
    END IF;

    INSERT INTO orders (customer_id, employee_id, required_date, priority, notes, status)
    VALUES (p_customer_id, p_employee_id, p_required_date, p_priority, p_notes, 'PENDING')
    RETURNING order_id INTO v_new_order_id;

    INSERT INTO audit_log (table_name, operation, record_id, changed_by, new_values)
    VALUES ('orders', 'I', v_new_order_id, current_user,
            '{"status":"PENDING","customer_id":' || p_customer_id::text || '}');

    RETURN v_new_order_id;

EXCEPTION
    WHEN OTHERS THEN
        RAISE;
END;
$$;

-- ── SP 2: Customer Order Summary (cursor → set-based) ────────────
-- NOTE: PL/pgSQL uses FOR loop instead of explicit CURSOR
CREATE OR REPLACE FUNCTION usp_customer_order_summary(
    p_customer_id       INT,
    p_include_cancelled BOOLEAN DEFAULT FALSE
)
RETURNS TABLE (
    order_id        INT,
    order_date      TIMESTAMP,
    status          VARCHAR(30),
    priority_label  VARCHAR(20),
    item_count      BIGINT,
    order_total     NUMERIC(12,2),
    has_shipment    CHAR(3)
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        o.order_id,
        o.order_date,
        o.status,
        CASE o.priority
            WHEN 1 THEN 'HIGH'
            WHEN 2 THEN 'NORMAL'
            ELSE        'LOW'
        END::VARCHAR(20)            AS priority_label,
        COUNT(oi.item_id)           AS item_count,
        o.total_amount,
        CASE WHEN EXISTS (
            SELECT 1 FROM shipments s WHERE s.order_id = o.order_id
        ) THEN 'YES' ELSE 'NO' END::CHAR(3) AS has_shipment
    FROM      orders o
    LEFT JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.customer_id = p_customer_id
      AND (p_include_cancelled OR o.status <> 'CANCELLED')
    GROUP BY o.order_id, o.order_date, o.status, o.priority, o.total_amount
    ORDER BY o.order_date DESC;
END;
$$;

-- ── SP 3: Check and Reorder Inventory ────────────────────────────
CREATE OR REPLACE FUNCTION usp_check_and_reorder_inventory(
    p_warehouse_id  INT     DEFAULT NULL,
    p_dry_run       BOOLEAN DEFAULT TRUE
)
RETURNS TABLE (
    warehouse_code  CHAR(6),
    sku             VARCHAR(50),
    current_stock   INT,
    reorder_point   INT,
    suggested_qty   INT,
    estimated_cost  NUMERIC(10,2),
    action_taken    TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Log reorders if not dry run (set-based, no cursor needed)
    IF NOT p_dry_run THEN
        INSERT INTO audit_log (table_name, operation, record_id, changed_by, new_values)
        SELECT
            'inventory', 'U', i.product_id, 'SYSTEM_REORDER',
            '{"action":"reorder_queued","warehouse_id":' || i.warehouse_id::text ||
            ',"qty":' || (i.reorder_point * 3)::text || '}'
        FROM       inventory   i
        INNER JOIN warehouses  w ON w.warehouse_id = i.warehouse_id
        INNER JOIN products    p ON p.product_id   = i.product_id
        WHERE i.qty_on_hand <= i.reorder_point
          AND p.is_active = TRUE
          AND w.is_active = TRUE
          AND (p_warehouse_id IS NULL OR i.warehouse_id = p_warehouse_id);
    END IF;

    RETURN QUERY
    SELECT
        w.warehouse_code,
        p.sku,
        i.qty_on_hand                          AS current_stock,
        i.reorder_point,
        i.reorder_point * 3                    AS suggested_qty,
        (i.reorder_point * 3 * p.unit_price)   AS estimated_cost,
        CASE WHEN p_dry_run
            THEN 'DRY RUN — no action taken'::TEXT
            ELSE 'REORDER QUEUED'::TEXT
        END                                     AS action_taken
    FROM       inventory   i
    INNER JOIN warehouses  w ON w.warehouse_id  = i.warehouse_id
    INNER JOIN products    p ON p.product_id    = i.product_id
    WHERE i.qty_on_hand <= i.reorder_point
      AND p.is_active = TRUE
      AND w.is_active = TRUE
      AND (p_warehouse_id IS NULL OR i.warehouse_id = p_warehouse_id)
    ORDER BY estimated_cost DESC;
END;
$$;
