#!/usr/bin/env python3
# ============================================================
#  migrate.py — Northstar Logistics Migration
#  SQLBits Demo, KGorman, 04/2026
#  Run on Windows: python migration\migrate.py
# ============================================================

import subprocess, sys, os

RUNTIME = os.environ.get("CONTAINER_RUNTIME", "podman")

GREEN  = "\033[0;32m"; CYAN = "\033[0;36m"
YELLOW = "\033[1;33m"; RED  = "\033[0;31m"
BOLD   = "\033[1m";    NC   = "\033[0m"

def log(m):    print(f"{CYAN}[migrate]{NC} {m}")
def ok(m):     print(f"{GREEN}[  OK  ]{NC} {m}")
def warn(m):   print(f"{YELLOW}[ WARN ]{NC} {m}")
def err(m):    print(f"{RED}[ FAIL ]{NC} {m}")
def banner(m):
    print(f"\n{BOLD}{CYAN}{'='*50}{NC}")
    print(f"{BOLD}{CYAN}  {m}{NC}")
    print(f"{BOLD}{CYAN}{'='*50}{NC}\n")

def run(cmd, input_data=None):
    return subprocess.run(cmd, input=input_data, capture_output=True, text=True)

def psql_stdin(sql):
    return run([RUNTIME,"exec","-i","northstar_postgres",
                "psql","-U","northstar","-d","northstar_logistics"],
               input_data=sql)

def sqlcmd_csv(table, cols):
    return run([RUNTIME,"exec","northstar_sqlserver",
                "/opt/mssql-tools18/bin/sqlcmd",
                "-S","localhost","-U","sa","-P","NorthstarDemo#2024",
                "-d","NorthstarLogistics","-No","-C",
                "-Q", f"SET NOCOUNT ON; SELECT {cols} FROM dbo.{table}",
                "-s",",","-W"])

# STEP 1: Schema
banner("STEP 1: Loading schema into PostgreSQL")
script_dir = os.path.dirname(os.path.abspath(__file__))
schema_file = os.path.join(script_dir, "01_schema.sql")
with open(schema_file, "r") as f:
    schema = f.read()
r = psql_stdin(schema)
if r.returncode == 0:
    ok("Schema loaded")
else:
    err("Schema failed: " + r.stderr)
    sys.exit(1)

# STEP 2: Data
banner("STEP 2: Migrating data")
TABLES = [
    ("departments","department_id,dept_name,cost_center,created_at"),
    ("employees",  "employee_id,department_id,first_name,last_name,email,hire_date,salary,is_active"),
    ("customers",  "customer_id,company_name,contact_name,email,phone,address_line1,city,state_province,postal_code,country,credit_limit,created_at,is_active"),
    ("carriers",   "carrier_id,carrier_name,scac_code,service_type,base_rate_per_mile,is_active"),
    ("warehouses", "warehouse_id,warehouse_code,warehouse_name,address,city,state_province,capacity_sqft,manager_emp_id,is_active"),
    ("routes",     "route_id,origin_wh_id,dest_wh_id,carrier_id,distance_miles,transit_days,is_active"),
    ("products",   "product_id,sku,product_name,category,unit_weight_lbs,unit_price,hazmat_flag,is_active"),
    ("inventory",  "inventory_id,warehouse_id,product_id,qty_on_hand,qty_reserved,reorder_point,last_updated"),
    ("orders",     "order_id,customer_id,employee_id,order_date,required_date,status,priority,total_amount,notes"),
    ("order_items","item_id,order_id,product_id,warehouse_id,quantity,unit_price,discount_pct"),
    ("shipments",  "shipment_id,order_id,route_id,tracking_number,ship_date,estimated_delivery,actual_delivery,status,weight_lbs,freight_cost"),
    ("audit_log",  "log_id,table_name,operation,record_id,changed_by,changed_at,old_values,new_values"),
]

for table, cols in TABLES:
    log(f"  {table}...")
    export = sqlcmd_csv(table, cols)
    if export.returncode != 0:
        warn(f"  {table}: export error")
        continue
    lines = export.stdout.splitlines()
    data  = [l for l in lines[2:] if l.strip() and not set(l.strip()) <= {'-', ' ', ','}]
    csv   = "\n".join(data) + "\n"
    if not csv.strip():
        warn(f"  {table}: no data")
        continue
    copy = f"COPY {table} ({cols}) FROM STDIN WITH (FORMAT csv, NULL 'NULL')"
    r = run([RUNTIME,"exec","-i","northstar_postgres",
             "psql","-U","northstar","-d","northstar_logistics","-c",copy],
            input_data=csv)
    if r.returncode == 0:
        ok(f"  {table}: done")
    else:
        warn(f"  {table}: {r.stderr.strip()}")

# STEP 3: Sequences
banner("STEP 3: Resetting sequences")
seqs = "\n".join([
    f"SELECT setval(pg_get_serial_sequence('{t}','{c}'), COALESCE(MAX({c}),1)) FROM {t};"
    for t,c in [
        ("departments","department_id"),("employees","employee_id"),
        ("customers","customer_id"),("carriers","carrier_id"),
        ("warehouses","warehouse_id"),("routes","route_id"),
        ("products","product_id"),("inventory","inventory_id"),
        ("orders","order_id"),("order_items","item_id"),
        ("shipments","shipment_id"),("audit_log","log_id"),
    ]
])
psql_stdin(seqs)
ok("Sequences reset")

# STEP 4: Validation
banner("STEP 4: Validation Report")
r = run([RUNTIME,"exec","northstar_postgres",
         "psql","-U","northstar","-d","northstar_logistics","-c",
         """SELECT tablename AS table_name,
            (xpath('/row/cnt/text()',
                query_to_xml('SELECT COUNT(*) AS cnt FROM '||tablename,false,true,''))
            )[1]::text::int AS row_count
            FROM pg_tables WHERE schemaname='public' ORDER BY tablename;"""])
print(r.stdout)

banner("MIGRATION COMPLETE")
ok("SQL Server 2019 -> PostgreSQL 17 migration finished")
