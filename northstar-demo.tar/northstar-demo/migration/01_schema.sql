-- ============================================================
--  SQLBits Demo KGorman PostgreSQL Schema
--  Migrated from SQL Server 2019
-- ============================================================

-- Drop tables in FK-safe order
DROP TABLE IF EXISTS audit_log    CASCADE;
DROP TABLE IF EXISTS shipments    CASCADE;
DROP TABLE IF EXISTS order_items  CASCADE;
DROP TABLE IF EXISTS orders       CASCADE;
DROP TABLE IF EXISTS inventory    CASCADE;
DROP TABLE IF EXISTS products     CASCADE;
DROP TABLE IF EXISTS routes       CASCADE;
DROP TABLE IF EXISTS warehouses   CASCADE;
DROP TABLE IF EXISTS carriers     CASCADE;
DROP TABLE IF EXISTS customers    CASCADE;
DROP TABLE IF EXISTS employees    CASCADE;
DROP TABLE IF EXISTS departments  CASCADE;

CREATE TABLE departments (
    department_id   SERIAL PRIMARY KEY,
    dept_name       VARCHAR(100) NOT NULL,
    cost_center     CHAR(6)      NOT NULL,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE employees (
    employee_id     SERIAL PRIMARY KEY,
    department_id   INT           NOT NULL,
    first_name      VARCHAR(80)   NOT NULL,
    last_name       VARCHAR(80)   NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    hire_date       DATE          NOT NULL,
    salary          NUMERIC(10,2) NOT NULL,
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_emp_dept FOREIGN KEY (department_id)
        REFERENCES departments(department_id)
);

CREATE TABLE customers (
    customer_id     SERIAL PRIMARY KEY,
    company_name    VARCHAR(200)  NOT NULL,
    contact_name    VARCHAR(150)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    phone           VARCHAR(30),
    address_line1   VARCHAR(255),
    city            VARCHAR(100),
    state_province  VARCHAR(100),
    postal_code     VARCHAR(20),
    country         VARCHAR(100)  NOT NULL DEFAULT 'US',
    credit_limit    NUMERIC(12,2) NOT NULL DEFAULT 50000.00,
    created_at      TIMESTAMP     NOT NULL DEFAULT NOW(),
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE
);

CREATE TABLE carriers (
    carrier_id         SERIAL PRIMARY KEY,
    carrier_name       VARCHAR(150)  NOT NULL,
    scac_code          CHAR(4)       NOT NULL UNIQUE,
    service_type       VARCHAR(50)   NOT NULL,
    base_rate_per_mile NUMERIC(8,4)  NOT NULL,
    is_active          BOOLEAN       NOT NULL DEFAULT TRUE
);

CREATE TABLE warehouses (
    warehouse_id    SERIAL PRIMARY KEY,
    warehouse_code  CHAR(6)       NOT NULL UNIQUE,
    warehouse_name  VARCHAR(150)  NOT NULL,
    address         VARCHAR(255)  NOT NULL,
    city            VARCHAR(100)  NOT NULL,
    state_province  VARCHAR(50)   NOT NULL,
    capacity_sqft   INT           NOT NULL,
    manager_emp_id  INT,
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE
);

CREATE TABLE routes (
    route_id        SERIAL PRIMARY KEY,
    origin_wh_id    INT           NOT NULL,
    dest_wh_id      INT           NOT NULL,
    carrier_id      INT           NOT NULL,
    distance_miles  NUMERIC(8,2)  NOT NULL,
    transit_days    SMALLINT      NOT NULL,
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_route_origin  FOREIGN KEY (origin_wh_id)  REFERENCES warehouses(warehouse_id),
    CONSTRAINT fk_route_dest    FOREIGN KEY (dest_wh_id)    REFERENCES warehouses(warehouse_id),
    CONSTRAINT fk_route_carrier FOREIGN KEY (carrier_id)    REFERENCES carriers(carrier_id)
);

CREATE TABLE products (
    product_id      SERIAL PRIMARY KEY,
    sku             VARCHAR(50)   NOT NULL UNIQUE,
    product_name    VARCHAR(200)  NOT NULL,
    category        VARCHAR(100)  NOT NULL,
    unit_weight_lbs NUMERIC(8,3)  NOT NULL,
    unit_price      NUMERIC(10,2) NOT NULL,
    hazmat_flag     BOOLEAN       NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE
);

CREATE TABLE inventory (
    inventory_id    SERIAL PRIMARY KEY,
    warehouse_id    INT           NOT NULL,
    product_id      INT           NOT NULL,
    qty_on_hand     INT           NOT NULL DEFAULT 0,
    qty_reserved    INT           NOT NULL DEFAULT 0,
    reorder_point   INT           NOT NULL DEFAULT 10,
    last_updated    TIMESTAMP     NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_inv_wh   FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    CONSTRAINT fk_inv_prod FOREIGN KEY (product_id)   REFERENCES products(product_id),
    CONSTRAINT uq_inv_wh_prod UNIQUE (warehouse_id, product_id)
);

CREATE TABLE orders (
    order_id        SERIAL PRIMARY KEY,
    customer_id     INT           NOT NULL,
    employee_id     INT           NOT NULL,
    order_date      TIMESTAMP     NOT NULL DEFAULT NOW(),
    required_date   DATE          NOT NULL,
    status          VARCHAR(30)   NOT NULL DEFAULT 'PENDING',
    priority        SMALLINT      NOT NULL DEFAULT 2,
    total_amount    NUMERIC(12,2) NOT NULL DEFAULT 0.00,
    notes           TEXT,
    CONSTRAINT fk_ord_cust FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    CONSTRAINT fk_ord_emp  FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    CONSTRAINT chk_order_status CHECK (status IN ('PENDING','CONFIRMED','SHIPPED','DELIVERED','CANCELLED'))
);

CREATE TABLE order_items (
    item_id         SERIAL PRIMARY KEY,
    order_id        INT           NOT NULL,
    product_id      INT           NOT NULL,
    warehouse_id    INT           NOT NULL,
    quantity        INT           NOT NULL,
    unit_price      NUMERIC(10,2) NOT NULL,
    discount_pct    NUMERIC(5,2)  NOT NULL DEFAULT 0.00,
    line_total      NUMERIC(12,2) GENERATED ALWAYS AS
                    (quantity * unit_price * (1 - discount_pct/100)) STORED,
    CONSTRAINT fk_oi_order FOREIGN KEY (order_id)     REFERENCES orders(order_id),
    CONSTRAINT fk_oi_prod  FOREIGN KEY (product_id)   REFERENCES products(product_id),
    CONSTRAINT fk_oi_wh    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

CREATE TABLE shipments (
    shipment_id         SERIAL PRIMARY KEY,
    order_id            INT           NOT NULL,
    route_id            INT           NOT NULL,
    tracking_number     VARCHAR(100)  NOT NULL UNIQUE,
    ship_date           TIMESTAMP,
    estimated_delivery  DATE,
    actual_delivery     TIMESTAMP,
    status              VARCHAR(30)   NOT NULL DEFAULT 'PENDING',
    weight_lbs          NUMERIC(10,3),
    freight_cost        NUMERIC(10,2),
    CONSTRAINT fk_ship_order FOREIGN KEY (order_id)  REFERENCES orders(order_id),
    CONSTRAINT fk_ship_route FOREIGN KEY (route_id)  REFERENCES routes(route_id),
    CONSTRAINT chk_ship_status CHECK (status IN ('PENDING','IN_TRANSIT','DELIVERED','EXCEPTION','RETURNED'))
);

CREATE TABLE audit_log (
    log_id          BIGSERIAL PRIMARY KEY,
    table_name      VARCHAR(100)  NOT NULL,
    operation       CHAR(1)       NOT NULL,
    record_id       INT           NOT NULL,
    changed_by      VARCHAR(150),
    changed_at      TIMESTAMP     NOT NULL DEFAULT NOW(),
    old_values      TEXT,
    new_values      TEXT
);

-- Indexes
CREATE INDEX idx_customers_email    ON customers(email);
CREATE INDEX idx_customers_company  ON customers(company_name);
CREATE INDEX idx_customers_active   ON customers(is_active) WHERE is_active = TRUE;
CREATE INDEX idx_orders_customer    ON orders(customer_id);
CREATE INDEX idx_orders_status_date ON orders(status, order_date DESC);
CREATE INDEX idx_orders_employee    ON orders(employee_id);
CREATE INDEX idx_oi_order           ON order_items(order_id);
CREATE INDEX idx_oi_product         ON order_items(product_id);
CREATE INDEX idx_ship_order         ON shipments(order_id);
CREATE INDEX idx_ship_tracking      ON shipments(tracking_number);
CREATE INDEX idx_ship_status        ON shipments(status);
CREATE INDEX idx_audit_table_date   ON audit_log(table_name, changed_at DESC);

